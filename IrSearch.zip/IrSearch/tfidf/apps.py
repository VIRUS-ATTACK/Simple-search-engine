from django.apps import AppConfig


class TfidfConfig(AppConfig):
    name = 'tfidf'
